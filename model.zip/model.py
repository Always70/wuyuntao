import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from einops import rearrange
import math


class PositionalEncoding(nn.Module):
    """修正后的正弦位置编码"""

    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, seq_len, device=None):
        if device is None:
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        position = torch.arange(0, seq_len, dtype=torch.float, device=device).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, self.dim, 2, device=device).float() *
                             (-math.log(10000.0) / self.dim))

        pos_enc = torch.zeros(1, seq_len, self.dim, device=device)
        pos_enc[0, :, 0::2] = torch.sin(position * div_term)
        pos_enc[0, :, 1::2] = torch.cos(position * div_term)
        return pos_enc


class TransformerBlock(nn.Module):
    """Transformer编码块"""

    def __init__(self, dim, num_heads, mlp_dim, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, mlp_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        x_norm = self.norm1(x)
        attn_out, _ = self.attn(x_norm, x_norm, x_norm)
        x = x + attn_out
        x = x + self.mlp(self.norm2(x))
        return x


class TransUNet(nn.Module):
    def __init__(self, in_channels=3, num_classes=1, hidden_dim=384, num_heads=6,
                 mlp_dim=1536, num_layers=6, patch_size=16):
        super().__init__()
        self.patch_size = patch_size

        # CNN编码器 (ResNet50) - 使用新的weights参数替代pretrained
        resnet = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        self.initial_conv = nn.Conv2d(in_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.initial_bn = resnet.bn1
        self.initial_relu = resnet.relu
        self.initial_maxpool = resnet.maxpool

        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4

        # 特征投影层 - 减小hidden_dim
        self.proj = nn.Conv2d(2048, hidden_dim, kernel_size=1)

        # Transformer - 减少层数和头数
        self.pos_encoding = PositionalEncoding(hidden_dim)
        transformer_blocks = [
            TransformerBlock(hidden_dim, num_heads, mlp_dim)
            for _ in range(num_layers)
        ]
        self.transformer = nn.Sequential(*transformer_blocks)

        # 解码器上采样路径
        self.up1 = nn.ConvTranspose2d(hidden_dim, 512, kernel_size=2, stride=2)
        self.decoder1 = nn.Sequential(
            nn.Conv2d(512 + 1024, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU()
        )

        self.up2 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.decoder2 = nn.Sequential(
            nn.Conv2d(256 + 512, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU()
        )

        self.up3 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.decoder3 = nn.Sequential(
            nn.Conv2d(128 + 256, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU()
        )

        self.up4 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.decoder4 = nn.Sequential(
            nn.Conv2d(64 + 64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU()
        )

        self.final_upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.final_conv = nn.Conv2d(64, num_classes, kernel_size=1)

    def forward(self, x):
        # 初始下采样
        x0 = self.initial_conv(x)
        x0 = self.initial_bn(x0)
        x0 = self.initial_relu(x0)
        x0 = self.initial_maxpool(x0)

        # 编码器路径
        e1 = self.encoder1(x0)  # [B, 256, H/4, W/4]
        e2 = self.encoder2(e1)  # [B, 512, H/8, W/8]
        e3 = self.encoder3(e2)  # [B, 1024, H/16, W/16]
        e4 = self.encoder4(e3)  # [B, 2048, H/32, W/32]

        # 投影到Transformer维度
        x = self.proj(e4)  # [B, hidden_dim, H/32, W/32]

        # 转换为序列
        b, c, h, w = x.shape
        x = rearrange(x, 'b c h w -> b (h w) c')

        # 添加位置编码
        seq_len = h * w
        pos_enc = self.pos_encoding(seq_len, x.device)
        x = x + pos_enc

        # Transformer处理
        x = self.transformer(x)

        # 转换回空间格式
        x = rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)

        # 解码器路径
        d1 = self.up1(x)
        d1 = F.interpolate(d1, size=e3.shape[2:], mode='bilinear', align_corners=True)
        d1 = torch.cat([d1, e3], dim=1)
        d1 = self.decoder1(d1)

        d2 = self.up2(d1)
        d2 = F.interpolate(d2, size=e2.shape[2:], mode='bilinear', align_corners=True)
        d2 = torch.cat([d2, e2], dim=1)
        d2 = self.decoder2(d2)

        d3 = self.up3(d2)
        d3 = F.interpolate(d3, size=e1.shape[2:], mode='bilinear', align_corners=True)
        d3 = torch.cat([d3, e1], dim=1)
        d3 = self.decoder3(d3)

        d4 = self.up4(d3)
        x0_up = F.interpolate(x0, size=d4.shape[2:], mode='bilinear', align_corners=True)
        d4 = torch.cat([d4, x0_up], dim=1)
        d4 = self.decoder4(d4)

        # 最终上采样和分类
        out = self.final_upsample(d4)
        out = self.final_conv(out)

        return out

# 测试代码
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 模型配置
    in_channels = 3
    num_classes = 1
    img_size = 224

    # 创建模型
    model = TransUNet(
        in_channels=in_channels,
        num_classes=num_classes,
        hidden_dim=768,
        num_heads=12,
        mlp_dim=3072,
        num_layers=12,
        patch_size=16
    ).to(device)

    # 打印模型参数数量
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {total_params:,}")

    # 模拟输入数据
    batch_size = 2
    x = torch.randn((batch_size, in_channels, img_size, img_size)).to(device)

    # 前向传播
    with torch.no_grad():
        output = model(x)

    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")  # 应该为 [batch_size, num_classes, img_size, img_size]