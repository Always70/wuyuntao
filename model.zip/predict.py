import glob
import numpy as np
import torch
import os
import cv2
from model import TransUNet


def calculate_metrics(pred_mask, gt_mask):
    """计算Dice系数和IoU"""
    pred_mask = pred_mask.astype(bool)
    gt_mask = gt_mask.astype(bool)

    intersection = np.logical_and(pred_mask, gt_mask).sum()
    union = np.logical_or(pred_mask, gt_mask).sum()

    dice = (2.0 * intersection) / (pred_mask.sum() + gt_mask.sum() + 1e-6)
    iou = intersection / (union + 1e-6)

    return dice, iou


if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = TransUNet(in_channels=1, num_classes=1)
    net.to(device=device)
    net.load_state_dict(torch.load('best_model_optimized1.pth', map_location=device))
    net.eval()

    tests_path = glob.glob('MoNuSegTestData/test_image/*.tif')
    gt_path = 'MoNuSegTestData/test_labels/'
    all_dice = []
    all_iou = []

    for test_path in tests_path:
        save_res_path = test_path.replace('test_image', 'save')
        os.makedirs(os.path.dirname(save_res_path), exist_ok=True)

        img = cv2.imread(test_path)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        img = img.reshape(1, 1, img.shape[0], img.shape[1]) / 255.0
        img_tensor = torch.from_numpy(img).to(device=device, dtype=torch.float32)

        with torch.no_grad():
            pred = net(img_tensor)

        pred_mask = np.array(pred.data.cpu()[0])[0]
        pred_mask[pred_mask >= 0.5] = 255
        pred_mask[pred_mask < 0.5] = 0
        cv2.imwrite(save_res_path, pred_mask)

        img_name = os.path.basename(test_path)
        # 关键修改：在文件名前添加label_前缀
        gt_name = f"label_{img_name}"
        gt_path_full = os.path.join(gt_path, gt_name)

        if os.path.exists(gt_path_full):
            gt_mask = cv2.imread(gt_path_full, 0)
            if gt_mask.shape != pred_mask.shape:
                gt_mask = cv2.resize(gt_mask, (pred_mask.shape[1], pred_mask.shape[0]),
                                     interpolation=cv2.INTER_NEAREST)
            gt_mask[gt_mask > 0] = 255

            dice, iou = calculate_metrics(pred_mask, gt_mask)
            all_dice.append(dice)
            all_iou.append(iou)

            print(f"Image: {img_name}, Dice: {dice:.4f}, IoU: {iou:.4f}")
        else:
            print(f"Warning: Ground truth not found for {img_name} - {gt_path_full}")

    if all_dice:
        avg_dice = np.mean(all_dice)
        avg_iou = np.mean(all_iou)
        print(f"\nOverall Metrics - Average Dice: {avg_dice:.4f}, Average IoU: {avg_iou:.4f}")
    else:
        print("No ground truth available to compute metrics")