from model import TransUNet
from dataset_loan import ISBI_Loader
from torch import optim
import torch.nn as nn
import torch
import matplotlib.pyplot as plt
from torch.cuda.amp import autocast, GradScaler

def train_net(net, device, data_path, epochs=40, batch_size=2, lr=0.00001, accumulation_steps=4):
    # 加载训练集
    isbi_dataset = ISBI_Loader(data_path)  # C H W
    train_loader = torch.utils.data.DataLoader(
        dataset=isbi_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=4,  # 增加工作线程数提高数据加载效率
        pin_memory=True,  # 锁页内存加速数据传输
        drop_last=True  # 丢弃最后一个不完整的批次
    )

    # 定义优化器
    optimizer = optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-4)  # 使用更高效的AdamW

    # 定义学习率调度器
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, verbose=True
    )

    # 定义Loss算法
    criterion = nn.BCEWithLogitsLoss()
                                                                                                                                                                                                                                                        
    # 混合精度训练
    scaler = GradScaler()

    # best_loss统计，初始化为正无穷
    best_loss = float('inf')
    # 训练epochs次
    losses = []
    for epoch in range(epochs):
        # 训练模式
        net.train()
        epoch_loss = 0
        # 梯度累积计数器
        optimizer.zero_grad()

        # 按照batch_size开始训练
        for i, (image, label) in enumerate(train_loader):
            # 将数据拷贝到device中
            image = image.to(device=device, dtype=torch.float32, non_blocking=True)
            label = label.to(device=device, dtype=torch.float32, non_blocking=True)

            # 混合精度训练
            with autocast():
                # 使用网络参数，输出预测结果
                pred = net(image)
                # 计算loss
                loss = criterion(pred, label)
                # 梯度累积
                loss = loss / accumulation_steps

            # 反向传播
            scaler.scale(loss).backward()

            # 梯度累积达到指定步数时更新参数
            if (i + 1) % accumulation_steps == 0:
                # 梯度裁剪，防止梯度爆炸
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(net.parameters(), max_norm=1.0)

                # 更新参数
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

            # 累加当前batch的loss
            epoch_loss += loss.item() * accumulation_steps

            # 每10个batch打印一次
            if (i + 1) % 10 == 0:
                print(
                    f'Epoch {epoch + 1}/{epochs}, Batch {i + 1}/{len(train_loader)}, Loss: {loss.item() * accumulation_steps:.6f}')

            # 释放不需要的变量
            del image, label, pred, loss
            torch.cuda.empty_cache()  # 定期清理缓存

        # 计算平均loss
        avg_epoch_loss = epoch_loss / len(train_loader)
        losses.append(avg_epoch_loss)

        # 更新学习率
        scheduler.step(avg_epoch_loss)

        print(f'Epoch {epoch + 1}/{epochs}, Average loss: {avg_epoch_loss:.6f}')

        # 保存loss值最小的网络参数
        if avg_epoch_loss < best_loss:
            best_loss = avg_epoch_loss
            torch.save(net.state_dict(), 'best_model_optimized2.pth')
            print(f'Saved best model with loss: {best_loss:.6f}')

    # 绘制loss曲线
    plt.plot(range(1, epochs + 1), losses)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss Curve')
    plt.savefig('training_loss_optimized.png')
    plt.show()


if __name__ == "__main__":
    # 选择设备，有cuda用cuda，没有就用cpu
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # 打印显存信息
    if torch.cuda.is_available():
        total_memory = torch.cuda.get_device_properties(device).total_memory / (1024 ** 3)
        print(f"Total GPU memory: {total_memory:.2f} GB")

    # 加载网络，图片单通道1，分类为1
    # 减小模型规模
    net = TransUNet(
        in_channels=1,
        num_classes=1,
        hidden_dim=384,  # 减小hidden_dim
        num_heads=6,  # 减少注意力头数
        mlp_dim=1536,  # 减小MLP维度
        num_layers=6  # 减少Transformer层数
    )

    # 将网络拷贝到device中
    net.to(device=device)

    # 指定训练集地址，开始训练
    data_path = "MoNuSeg 2018 Training Data/"

    # 梯度累积，等效于增大batch_size但不增加显存占用
    accumulation_steps = 4

    # 减小实际batch_size，但通过累积达到等效效果
    effective_batch_size = 8
    batch_size = effective_batch_size // accumulation_steps

    train_net(
        net=net,
        device=device,
        data_path=data_path,
        epochs=70,
        batch_size=batch_size,
        lr=0.0001,
        accumulation_steps=accumulation_steps
    )

