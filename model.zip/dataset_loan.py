import torch
import cv2
import os
import glob
from torch.utils.data import Dataset
import random
import matplotlib.pyplot as plt

class ISBI_Loader(Dataset):
    def __init__(self, data_path):
        # 初始化函数，读取所有data_path下的图片
        self.data_path = data_path  # data/train/
        self.imgs_path = glob.glob(os.path.join(data_path, 'train_Images/*.tif'))  # data/train/image/*.png
        self.label_path = glob.glob(os.path.join(data_path, 'train_labels/*.tif')) # data/train/image/*.png

    def augment(self, image, flipCode):
        # 使用cv2.flip进行数据增强，filpCode为1水平翻转，0垂直翻转，-1水平+垂直翻转
        # 先调整维度为H×W格式，然后再进行翻转，最后恢复原始维度
        original_shape = image.shape
        # 调整为H×W格式
        image_2d = image.reshape(image.shape[1], image.shape[2])
        # 执行翻转操作
        flip = cv2.flip(image_2d, flipCode)
        # 恢复原始维度
        flip = flip.reshape(original_shape)
        return flip

    def __getitem__(self, index):
        # 根据index读取图片
        image_path = self.imgs_path[index]  # index 3  "data/train/image/3.png"
        label_path = self.label_path[index]
        # 根据image_path生成label_path
        #label_path = image_path.replace('image', 'label')  # index 2  data/train/label/2.png
        # save_path = image_path.replace('image', 'save')  # index 2  data/train/label/2.png
        # label_path = self.label_path[index]
        # 读取训练图片和标签图片
        image = cv2.imread(image_path)
        label = cv2.imread(label_path)

        # 将数据转为单通道的图片
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        label = cv2.cvtColor(label, cv2.COLOR_BGR2GRAY)  # H W C
        image = image.reshape(1, image.shape[0], image.shape[1])  # B C H W   C 设置为 1 变成为 C H W
        label = label.reshape(1, label.shape[0], label.shape[1])
        # 处理标签，将像素值为255的改为1
        if label.max() > 1:
            label = label / 255.0
        if image.max() > 1:
            image = image / 255.0
        # 随机进行数据增强，为2时不做处理
        flipCode = random.choice([-1, 0, 1, 2])
        if flipCode != 2:
            image = self.augment(image, flipCode)
            label = self.augment(label, flipCode)
        # cv2.imwrite(save_path, image.reshape(image.shape[1], image.shape[2])*255)
        return image, label

    def __len__(self):
        # 返回训练集大小
        return len(self.imgs_path)

    def show_image(self, index):
        # 根据索引展示指定的训练图像和标签图像
        image, label = self[index]
        image = image.squeeze()
        label = label.squeeze()
        fig, ax = plt.subplots(1, 2)
        ax[0].imshow(image, cmap='gray')
        ax[0].set_title('Training Image')
        ax[1].imshow(label, cmap='gray')
        ax[1].set_title('Label Image')
        plt.show()


if __name__ == "__main__":
    isbi_dataset = ISBI_Loader("MoNuSeg 2018 Training Data/")
    print("数据个数：", len(isbi_dataset))
    train_loader = torch.utils.data.DataLoader(dataset=isbi_dataset,
                                               batch_size=2,
                                               shuffle=False)  # C H W --> B C H W
    for image, label in train_loader:
        print(image.shape)
        print(label.shape)
        break

    isbi_dataset.show_image(0)
